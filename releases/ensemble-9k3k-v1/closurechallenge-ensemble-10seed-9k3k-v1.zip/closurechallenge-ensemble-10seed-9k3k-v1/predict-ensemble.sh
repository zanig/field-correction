#!/bin/sh
set -eu
python predict.py \
  checkpoints/seed1234.pt \
  checkpoints/seed4321.pt \
  checkpoints/seed1337.pt \
  checkpoints/seed1338.pt \
  checkpoints/seed777.pt \
  checkpoints/seed9153.pt \
  checkpoints/seed17072.pt \
  checkpoints/seed2024.pt \
  checkpoints/seed2025.pt \
  checkpoints/seed42.pt \
  --cache cache.npz --out predictions
