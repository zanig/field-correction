# Closure Challenge: ten-seed velocity-correction ensemble

This download contains the ten trained checkpoints, the exact nine source files
used for the run, and eight prediction CSVs in `test/`.
The official `closure-challenge==0.3.1` evaluator gives an overall error of
**0.0425321534** (lower is better). Individual members score between 0.0443
and 0.0582 (mean 0.0492).

| Case | RANS baseline | This ensemble |
|---|---|---|
| `alpha_15_13929_4048` | 0.1320 | 0.0244 |
| `alpha_15_13929_2024` | 0.2049 | 0.0204 |
| `alpha_05_4071_4048` | 0.0461 | 0.0306 |
| `alpha_05_4071_2024` | 0.0719 | 0.0451 |
| `AR_1_Ret_360` | 0.1288 | 0.0571 |
| `AR_3_Ret_360` | 0.1243 | 0.0557 |
| `AR_14_Ret_180` | 0.0590 | 0.0215 |
| `NASA_2DWMH` | 0.0621 | 0.0854 |
| Overall | 0.1036 | 0.0425 |

On `NASA_2DWMH` the correction is worse than the uncorrected RANS baseline;
every individual member is worse than the baseline there too.

The model predicts an additive velocity correction from RANS fields and geometry.
A first phase trains a reference encoder/predictor and decoder using LES/DNS.
A second phase freezes the reference branch and decoder and trains a RANS
encoder/predictor using latent alignment and velocity reconstruction.
Inference uses RANS fields and geometry.

All ten members use 9,000 reference-phase steps and 3,000 RANS-phase steps,
zero dropout, and all 32 non-test cases. Their physical velocity predictions
are averaged with equal weights. The seeds, recipe, case names, dependency
versions, and checkpoint/source hashes are recorded in `ensemble.json`.

## Install

Run the commands from this extracted directory. The original run used Python
3.12.12 on macOS/CPU; Python 3.12 is recommended.

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Score the supplied CSVs

This needs the evaluator dependency but does not need the raw CFD data or cache.
The eight CSVs have no header and contain the three velocity components in the
official evaluation-point order.

```sh
python score.py test --out scores-recomputed.json
```

The expected overall error is `0.04253215338353542`. Per-case errors are in
`scores.json`.

## Regenerate the predictions

Obtain the Closure Challenge data from the benchmark repository linked below.
The data directory must contain `Parm_PH_29`, `DUCT`, `CBFS`, `PH_Breuer`,
`NASA_2DWMH`, and `evaluation_points`.

```sh
python prep.py /path/to/closure-challenge-benchmark/data --out cache.npz
sh predict-ensemble.sh
python score.py predictions --out scores-regenerated.json
```

`predict-ensemble.sh` supplies all ten checkpoints to `predict.py` in the declared
order. The regenerated files are written to `predictions/`; the supplied CSVs
remain in `test/`. A bare `python predict.py` uses only seed 1234.

Use the pinned dependencies for preprocessing as well as inference. The cache
check hashes array contents; small changes to those contents, including changes
introduced by another NumPy version, can still produce a mismatch. Exact
floating-point reproducibility across platforms is not guaranteed.

## Retrain

This command trains ten new models from scratch. Use a new output directory.
The supplied checkpoint hashes identify the released weights; a fresh run on
another platform may produce different weights and scores.

```sh
python -u train.py --seeds 1234 4321 1337 1338 777 9153 17072 2024 2025 42 \
  --steps 9000 3000 --threads 1 --device cpu --out runs/retrained
```

To evaluate retrained models, supply the ten `runs/retrained/seed*.pt` paths to
`predict.py` in the same seed order as `predict-ensemble.sh`.

## Development and evaluation

The 9k/3k schedule followed an exploratory one-seed comparison on five held-out
non-test validation cases, where it narrowly outperformed 20k/10k. Final fitting
used all 32 non-test cases, including those validation cases. No test cases
were used to fit the model weights.

Public evaluator scores were also previewed during development for training-
length, regularization, and ensemble experiments. The decision to try this
ensemble followed earlier single-model test results. The ten seeds and equal
weights were fixed before scoring this ensemble, and every member is included.

This is a direct field correction; it does not enforce the governing equations.

Benchmark data, rules, and submission instructions:
https://github.com/rmcconke/closure-challenge-benchmark

`SHA256SUMS` records the contents of this download. On macOS, verify with:

```sh
shasum -a 256 -c SHA256SUMS
```
