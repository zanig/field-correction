# Closure Challenge: ten-seed velocity-correction ensemble (v2)

This download contains the ten trained checkpoints, the exact nine source files
used for the run, and eight prediction CSVs in `test/`.
The official `closure-challenge==0.3.1` evaluator gives an overall error of
**0.0406128562** (lower is better). Individual members score between 0.0407
and 0.0487 (mean 0.0448).

| Case | RANS baseline | This ensemble |
|---|---|---|
| `alpha_15_13929_4048` | 0.1320 | 0.0238 |
| `alpha_15_13929_2024` | 0.2049 | 0.0151 |
| `alpha_05_4071_4048` | 0.0461 | 0.0298 |
| `alpha_05_4071_2024` | 0.0719 | 0.0466 |
| `AR_1_Ret_360` | 0.1288 | 0.0576 |
| `AR_3_Ret_360` | 0.1243 | 0.0491 |
| `AR_14_Ret_180` | 0.0590 | 0.0202 |
| `NASA_2DWMH` | 0.0621 | 0.0828 |
| Overall | 0.1036 | 0.0406 |

On `NASA_2DWMH` the correction is worse than the uncorrected RANS baseline;
every individual member is worse than the baseline there too.

The model predicts an additive velocity correction from RANS fields and geometry.
A first phase trains a reference encoder/predictor and decoder using LES/DNS.
A second phase freezes the reference branch and decoder and trains a RANS
encoder/predictor using latent alignment and velocity reconstruction.
Inference uses RANS fields and geometry.

Each member has 87,523 parameters (8 latent tokens, latent dimension 32, hidden
width 64). All ten members use 9,000 reference-phase steps and 3,000 RANS-phase
steps, zero dropout, and all 32 non-test cases. Their physical velocity
predictions are averaged with equal weights. The seeds, recipe, case names,
dependency versions, and checkpoint/source hashes are recorded in
`ensemble.json`.

## Install

Run the commands from this extracted directory. The original run used Python
3.12.12 on macOS/CPU; Python 3.12 is recommended.

```sh
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

## Score the supplied CSVs

This needs the evaluator dependency but does not need the raw CFD data or cache.
The eight CSVs have no header and contain the three velocity components in the
official evaluation-point order.

```sh
python score.py test --out scores-recomputed.json
```

The expected overall error is `0.040612856163881106`. Per-case errors are in
`scores.json`.

## Regenerate the predictions

Obtain the Closure Challenge data from the benchmark repository linked below.
The data directory must contain `Parm_PH_29`, `DUCT`, `CBFS`, `PH_Breuer`,
`NASA_2DWMH`, and `evaluation_points`.

```sh
python prep.py /path/to/closure-challenge-benchmark/data --out cache.npz
sh predict-ensemble.sh
python score.py predictions --out scores-regenerated.json
```

`predict-ensemble.sh` supplies all ten checkpoints to `predict.py` in the declared
order. The regenerated files are written to `predictions/`; the supplied CSVs
remain in `test/`. A bare `python predict.py` uses only seed 1234.

Use the pinned dependencies for preprocessing as well as inference. The cache
check hashes array contents; small changes to those contents, including changes
introduced by another NumPy version, can still produce a mismatch. Exact
floating-point reproducibility across platforms is not guaranteed.

## Retrain

This command trains ten new models from scratch. Use a new output directory.
The supplied checkpoint hashes identify the released weights; a fresh run on
another platform may produce different weights and scores.

```sh
python -u train.py --seeds 1234 4321 1337 1338 777 9153 17072 2024 2025 42 \
  --steps 9000 3000 --threads 1 --device cpu --out runs/retrained
```

To evaluate retrained models, supply the ten `runs/retrained/seed*.pt` paths to
`predict.py` in the same seed order as `predict-ensemble.sh`.

## Development and evaluation

No test cases were used to fit the model weights. The test set was, however,
looked at during development, and this is the second ensemble scored on it.

**Version 1.** An earlier ensemble used a smaller model (4 latent tokens, latent
dimension 16, hidden width 32; 24,691 parameters) with the same recipe, seeds
and pipeline. It scored 0.0425321534. Public evaluator scores were previewed
while developing it, for training-length, regularization, ensemble and
frame-alignment experiments, and the decision to try an ensemble followed
single-model test results. The size of that smaller model was not chosen on
validation. The 9k/3k schedule followed an exploratory one-seed comparison on
five held-out non-test validation cases, where it narrowly outperformed 20k/10k.

**Version 2 (this download).** The only change from version 1 is the model
size. It was chosen from a sweep that never loaded the test split or the
evaluator: eight sizes, two seeds each, trained on 27 cases and compared on the
five held-out validation cases.

| Latent tokens, latent dim, width | Parameters | Validation error, mean of two seeds |
|---|---|---|
| 8, 32, 64 (this release) | 87,523 | 0.0242 |
| 4, 16, 64 | 46,003 | 0.0246 |
| 4, 32, 32 | 60,323 | 0.0262 |
| 4, 16, 32 (version 1) | 24,691 | 0.0272 |
| 2, 16, 32 | 24,627 | 0.0291 |
| 8, 16, 32 | 24,819 | 0.0306 |
| 4, 8, 32 | 13,787 | 0.0322 |
| 4, 16, 16 | 17,107 | 0.0367 |

Two seeds of the same size differ by 0.001 to 0.004, so neighbouring rows are
not reliably different. The size with the lowest mean was taken. The size, the
ten seeds and the equal weights were written down before this ensemble was
trained, it was scored once, and every member is included. Final fitting used
all 32 non-test cases, including the five validation cases.

Everything other than the size (recipe, seeds, the ensemble itself, the rest of
the pipeline) is inherited from version 1 and so carries the test exposure
described above.

Known limitation: `NASA_2DWMH` is supplied in the x-z plane, while every 2D
training case lies in the x-y plane, and this pipeline does not realign it.
Realigning it at inference was tried with version 1 and scored slightly worse
there (0.0426940638 overall instead of 0.0425321534). It was not tried with
this version.

This is a direct field correction; it does not enforce the governing equations.

Benchmark data, rules, and submission instructions:
https://github.com/rmcconke/closure-challenge-benchmark

`SHA256SUMS` records the contents of this download. On macOS, verify with:

```sh
shasum -a 256 -c SHA256SUMS
```
